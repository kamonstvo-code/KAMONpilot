import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

@main
struct KAMONpilotApp: App {
    @AppStorage("kamonpilot.theme") private var savedTheme = AppTheme.deepBlack.rawValue

    var body: some Scene {
        WindowGroup {
            KAMONpilotView()
                .preferredColorScheme(.dark)
        }
    }
}

enum AppTheme: String, CaseIterable, Identifiable {
    case darkBlue = "Dark Blue"
    case white = "White"
    case deepBlack = "Deep Black"

    var id: String { rawValue }

    var background: Color {
        switch self {
        case .darkBlue: return Color(red: 0.015, green: 0.055, blue: 0.19)
        case .white: return Color(red: 0.96, green: 0.96, blue: 0.96)
        case .deepBlack: return Color(red: 0.025, green: 0.025, blue: 0.03)
        }
    }

    var panel: Color {
        switch self {
        case .darkBlue: return Color(red: 0.035, green: 0.12, blue: 0.34)
        case .white: return Color(red: 0.88, green: 0.88, blue: 0.88)
        case .deepBlack: return Color(red: 0.09, green: 0.09, blue: 0.10)
        }
    }

    var input: Color {
        switch self {
        case .darkBlue: return Color(red: 0.025, green: 0.22, blue: 0.56)
        case .white: return Color(red: 0.77, green: 0.77, blue: 0.77)
        case .deepBlack: return Color(red: 0.17, green: 0.17, blue: 0.18)
        }
    }

    var foreground: Color {
        self == .white ? .black : .white
    }
}

struct ChatMessage: Identifiable {
    let id = UUID()
    let text: String
    let fromUser: Bool
}

struct KAMONpilotView: View {
    @AppStorage("kamonpilot.theme") private var themeName = AppTheme.deepBlack.rawValue
    @State private var chats = ["Новий чат"]
    @State private var selectedChat = "Новий чат"
    @State private var draft = ""
    @State private var messages: [ChatMessage] = []
    @State private var showingSettings = false
    @State private var showingAttachOptions = false
    @State private var showingImageNotice = false
    @State private var showingVideoNotice = false
    @State private var showingNewProject = false
    @State private var projectName = ""
    @State private var isThinking = false
    @State private var errorMessage: String?
    @State private var apiKey = ""
    @State private var modelName = "gpt-4.1-mini"

    private var theme: AppTheme { AppTheme(rawValue: themeName) ?? .deepBlack }

    var body: some View {
        GeometryReader { geometry in
            HStack(spacing: 12) {
                sidebar
                    .frame(width: max(220, geometry.size.width * 0.225))
                mainChat
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .padding(12)
            .background(theme.background)
            .foregroundStyle(theme.foreground)
        }
        .background(theme.background.ignoresSafeArea())
        .preferredColorScheme(theme == .white ? .light : .dark)
        .sheet(isPresented: $showingSettings) {
            settingsSheet
                .presentationDetents([.medium, .large])
        }
        .confirmationDialog("Додати до повідомлення", isPresented: $showingAttachOptions) {
            Button("Вибрати зображення") { showingImageNotice = true }
            Button("Вибрати файл") { showingImageNotice = true }
            Button("Скасувати", role: .cancel) {}
        }
        .alert("Генерація зображень", isPresented: $showingImageNotice) {
            Button("Гаразд", role: .cancel) {}
        } message: {
            Text("Інтерфейс готовий. Для реальної генерації потрібно підключити сумісний сервіс або модель.")
        }
        .alert("Генерація відео", isPresented: $showingVideoNotice) {
            Button("Гаразд", role: .cancel) {}
        } message: {
            Text("Для генерації відео потрібен окремий сервіс або модель. Ця функція ще не підключена.")
        }
        .alert("Новий проєкт", isPresented: $showingNewProject) {
            TextField("Назва проєкту", text: $projectName)
            Button("Створити") {
                let name = projectName.trimmingCharacters(in: .whitespacesAndNewlines)
                if !name.isEmpty {
                    chats.insert("Проєкт: \(name)", at: 0)
                    selectedChat = "Проєкт: \(name)"
                    messages = []
                    projectName = ""
                }
            }
            Button("Скасувати", role: .cancel) { projectName = "" }
        } message: {
            Text("Створи окремий простір для розмови.")
        }
    }

    private var sidebar: some View {
        VStack(spacing: 10) {
            HStack {
                Image(systemName: "infinity")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundStyle(
                        LinearGradient(colors: [.cyan, .blue, .purple, .pink, .orange],
                                       startPoint: .leading, endPoint: .trailing)
                    )
                Text("KAMONpilot")
                    .font(.headline.weight(.semibold))
                    .lineLimit(1)
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 14)
            .frame(height: 62)
            .background(theme.panel, in: Capsule())

            ScrollView {
                VStack(spacing: 8) {
                    ForEach(chats, id: \.self) { chat in
                        Button {
                            selectedChat = chat
                            messages = []
                        } label: {
                            HStack {
                                Image(systemName: chat.hasPrefix("Проєкт:") ? "folder" : "bubble.left.and.bubble.right")
                                Text(chat).lineLimit(2)
                                Spacer(minLength: 0)
                            }
                            .font(.subheadline)
                            .padding(12)
                            .frame(maxWidth: .infinity, minHeight: 54, alignment: .leading)
                            .background(selectedChat == chat ? Color.blue.opacity(0.8) : theme.panel,
                                        in: RoundedRectangle(cornerRadius: 18))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .scrollIndicators(.hidden)

            Rectangle().fill(Color.cyan).frame(height: 3)

            VStack(spacing: 0) {
                menuButton("Генерувати зображення", icon: "photo", action: { showingImageNotice = true })
                menuButton("Генерувати відео", icon: "video", action: { showingVideoNotice = true })
                HStack(spacing: 4) {
                    menuButton("Новий чат", icon: "plus.bubble", compact: true, action: createChat)
                    menuButton("Новий проєкт", icon: "folder.badge.plus", compact: true, action: { showingNewProject = true })
                }
                menuButton("Налаштування", icon: "gearshape", action: { showingSettings = true })
            }
            .padding(6)
            .background(theme.panel, in: RoundedRectangle(cornerRadius: 24))
        }
        .padding(8)
        .background(theme.panel.opacity(0.55), in: RoundedRectangle(cornerRadius: 28))
    }

    private func menuButton(_ title: String, icon: String, compact: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                Text(title).lineLimit(1).minimumScaleFactor(0.65)
            }
            .font(compact ? .caption.weight(.medium) : .subheadline.weight(.medium))
            .frame(maxWidth: .infinity, minHeight: compact ? 46 : 48)
            .foregroundStyle(theme == .white ? Color.purple : Color(red: 0.72, green: 0.48, blue: 1))
            .overlay(alignment: .bottom) {
                Rectangle().fill(Color.purple).frame(height: 2)
            }
        }
        .buttonStyle(.plain)
    }

    private var mainChat: some View {
        VStack(spacing: 0) {
            if messages.isEmpty {
                Spacer()
                VStack(spacing: 12) {
                    Text("KAMONpilot")
                        .font(.system(size: 32, weight: .semibold))
                    Text("Чим можу допомогти?")
                        .font(.title3)
                        .foregroundStyle(theme.foreground.opacity(0.7))
                }
                Spacer()
            } else {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 14) {
                            ForEach(messages) { message in
                                HStack {
                                    if message.fromUser { Spacer(minLength: 45) }
                                    Text(message.text)
                                        .textSelection(.enabled)
                                        .padding(14)
                                        .background(message.fromUser ? Color.blue.opacity(0.85) : theme.panel,
                                                    in: RoundedRectangle(cornerRadius: 18))
                                    if !message.fromUser { Spacer(minLength: 45) }
                                }
                                .id(message.id)
                            }
                            if isThinking {
                                HStack(spacing: 8) {
                                    ProgressView().tint(theme.foreground)
                                    Text("KAMONpilot думає…").foregroundStyle(theme.foreground.opacity(0.7))
                                    Spacer()
                                }
                                .padding(12)
                            }
                        }
                        .padding()
                    }
                    .onChange(of: messages.count) {
                        if let last = messages.last { proxy.scrollTo(last.id, anchor: .bottom) }
                    }
                }
            }

            if let errorMessage {
                Text(errorMessage)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .padding(.horizontal, 16)
            }

            HStack(alignment: .bottom, spacing: 12) {
                Button { showingAttachOptions = true } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 26, weight: .bold))
                        .frame(width: 44, height: 52)
                        .foregroundStyle(theme.foreground)
                }
                .buttonStyle(.plain)

                TextField("Напишіть повідомлення…", text: $draft, axis: .vertical)
                    .lineLimit(1...5)
                    .padding(.vertical, 14)
                    .textFieldStyle(.plain)
                    .onSubmit { sendMessage() }
                    .disabled(isThinking)

                Button {
                    errorMessage = "Голосове введення ще не підключено в цій збірці."
                } label: {
                    Image(systemName: "waveform")
                        .font(.system(size: 23, weight: .semibold))
                        .frame(width: 44, height: 52)
                        .foregroundStyle(.cyan)
                }
                .buttonStyle(.plain)

                Button(action: sendMessage) {
                    Image(systemName: "arrow.up")
                        .font(.system(size: 18, weight: .bold))
                        .frame(width: 42, height: 42)
                        .background(Color.purple, in: Circle())
                        .foregroundStyle(.white)
                }
                .buttonStyle(.plain)
                .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isThinking)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(theme.input, in: RoundedRectangle(cornerRadius: 28))
            .padding(12)
        }
        .background(theme.panel.opacity(0.7), in: RoundedRectangle(cornerRadius: 30))
    }

    private var settingsSheet: some View {
        NavigationStack {
            Form {
                Section("Кольорова тема") {
                    Picker("Тема", selection: $themeName) {
                        ForEach(AppTheme.allCases) { item in
                            Text(item.rawValue).tag(item.rawValue)
                        }
                    }
                    .pickerStyle(.inline)
                }
                Section("Мовна модель") {
                    SecureField("API-ключ (необов’язково)", text: $apiKey)
                    TextField("Назва моделі", text: $modelName)
                    Text("Ключ зберігається лише на цьому пристрої в налаштуваннях програми. Не додавай ключ до публічного коду.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                Section {
                    Text("KAMONpilot — ранній прототип. Для справжніх відповідей потрібен API-ключ сумісного сервісу. Ця версія ще не є готовою App Store-програмою.")
                        .font(.footnote)
                }
            }
            .navigationTitle("Налаштування")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { showingSettings = false }
                }
            }
        }
    }

    private func createChat() {
        let name = "Чат \(chats.filter { $0.hasPrefix("Чат ") || $0 == "Новий чат" }.count + 1)"
        chats.insert(name, at: 0)
        selectedChat = name
        messages = []
        errorMessage = nil
    }

    private func sendMessage() {
        let prompt = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty else { return }
        messages.append(ChatMessage(text: prompt, fromUser: true))
        draft = ""
        errorMessage = nil

        guard !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            messages.append(ChatMessage(
                text: "Інтерфейс працює, але ШІ ще не підключений. Відкрий Налаштування й додай API-ключ сумісного сервісу. Без ключа я не буду імітувати відповідь ШІ.",
                fromUser: false
            ))
            return
        }

        isThinking = true
        Task {
            do {
                let answer = try await AIClient.reply(
                    prompt: prompt,
                    apiKey: apiKey,
                    model: modelName.isEmpty ? "gpt-4.1-mini" : modelName
                )
                await MainActor.run {
                    messages.append(ChatMessage(text: answer, fromUser: false))
                    isThinking = false
                }
            } catch {
                await MainActor.run {
                    errorMessage = "Не вдалося отримати відповідь: \(error.localizedDescription)"
                    isThinking = false
                }
            }
        }
    }
}

enum AIClient {
    static func reply(prompt: String, apiKey: String, model: String) async throws -> String {
        guard let url = URL(string: "https://api.openai.com/v1/chat/completions") else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "model": model,
            "messages": [
                ["role": "system", "content": "You are KAMONpilot, an AI assistant created by KAMON COMPANY. Respond helpfully and clearly."],
                ["role": "user", "content": prompt]
            ],
            "stream": false
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        guard (200..<300).contains(http.statusCode) else {
            let details = String(data: data, encoding: .utf8) ?? "Невідома помилка"
            throw NSError(domain: "KAMONpilot.API", code: http.statusCode,
                          userInfo: [NSLocalizedDescriptionKey: details])
        }
        let decoded = try JSONDecoder().decode(ChatCompletionResponse.self, from: data)
        guard let text = decoded.choices.first?.message.content, !text.isEmpty else {
            throw URLError(.cannotDecodeContentData)
        }
        return text
    }
}

struct ChatCompletionResponse: Decodable {
    struct Choice: Decodable {
        struct Message: Decodable { let content: String }
        let message: Message
    }
    let choices: [Choice]
}

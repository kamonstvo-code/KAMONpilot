# KAMONpilot for iPadOS — starter project

This is a SwiftUI starter source for the KAMONpilot concept. It is **not a compiled or installable iPad app** yet.

## Included
- Three themes: Deep Black (default), Dark Blue, White.
- Landscape-style two-pane chat layout.
- Sidebar, chat list, new chat, new project, settings.
- Message composer and attachment/voice UI controls.
- Optional OpenAI-compatible Chat Completions API connection in the source.

## Important limitations
- Image and video generation are not connected.
- Voice input is a UI placeholder, not speech recognition.
- File/image attachment is a UI placeholder.
- To receive actual AI replies, enter a valid API key in Settings and use a model name supported by the configured API. API availability, billing, and model access depend on the provider.
- The API key is stored in `@State` for this starter prototype, so it is not persisted across launches. For a production app, use Keychain and preferably a secure backend proxy; embedding API keys in a client app is not safe.
- The request currently targets `https://api.openai.com/v1/chat/completions`. It will not connect to Ollama automatically.
- You need a Mac with Xcode to build/sign a native SwiftUI app for iPadOS. This folder alone is source, not an `.ipa`.

## Create the Xcode project
1. On a Mac, open Xcode and choose **File → New → Project → iOS → App**.
2. Product Name: `KAMONpilot`; Interface: `SwiftUI`; Language: `Swift`.
3. Replace the generated app Swift file with `KAMONpilotApp.swift` from this folder.
4. Set the deployment target to a suitable iPadOS version and run on an iPad simulator/device.
5. Before distributing, replace the demo networking design with secure key storage/backend and implement attachment, voice, image generation, and video generation.

## Default appearance
The selected theme defaults to `Deep Black` and the chosen theme is saved with `@AppStorage`.
